**Here, the purpose is to get some prediction for the 4 following crash profiles that do not exist in the “road-accident” dataset :
According to  data, we want an estimation of**
1. the number of deaths in a road crash located in a completely dark (2) rural (1) road of Texas (48) occurring a rainy (2) friday (6) involving 2 vehicles 4 people and 1 drunk driver.
2. the number of deaths in a road crash fitting the same previous profile but without any drunk drivers
3. the number of deaths in a road crash located in a completely dark (2) rural (1) road of California (6) occurring a rainy (2) friday (6) involving 2 vehicles 5 people and 1 drunk driver.
4. the number of deaths in a road crash fitting the same previous profile but without any drunk drivers

### prediction of the number of deaths in a car accident in Texas (48), a friday (6), during a night without lights (2), when raining (2), on a rural road (1) involving 2 vehicles 4 people and 1 drunk driver.